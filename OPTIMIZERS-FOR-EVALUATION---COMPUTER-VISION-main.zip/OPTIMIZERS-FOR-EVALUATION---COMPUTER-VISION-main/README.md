# OPTIMIZERS-FOR-EVALUATION---COMPUTER-VISION
Performed classification on the CIFAR10 dataset. The dataset consists of color images of objects from 10 classes. Reported runtime, train-test classification accuracy, and loss values at the first and last epoch, for each of the optimizers listed below
1. Adam 
2. SGD 
3. AdaDelta 
4. RMSprop




Also made a report of the findings
